package com.maveric.customerwithMongoDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerwithMongoDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
