package com.maveric.customerwithMongoDB.service;

public class CustomerService {

}
