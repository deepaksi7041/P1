package com.maveric.customerwithMongoDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class CustomerwithMongoDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerwithMongoDbApplication.class, args);
	}

}
