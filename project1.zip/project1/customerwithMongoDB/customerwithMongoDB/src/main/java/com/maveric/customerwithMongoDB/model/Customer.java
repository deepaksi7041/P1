package com.maveric.customerwithMongoDB.model;

import com.sun.istack.internal.NotNull;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection="customer")
@Data
public class Customer {
    @Id
    @NotNull
    private Long customerId;
    @NotNull
    private String firstName;
    private String lastName;
    private String middleName;
    private String email_id;
    private String address;
    private String phoneNumber;



}
