package com.maveric.customerwithMongoDB.model;

public class Address {
    private String street;
    private String city;
    private String State;
    private String pincode;

}
