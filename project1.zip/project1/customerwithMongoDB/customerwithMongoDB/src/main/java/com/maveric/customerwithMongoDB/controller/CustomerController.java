package com.maveric.customerwithMongoDB.controller;


import com.maveric.customerwithMongoDB.model.Customer;
import com.maveric.customerwithMongoDB.repository.CustomerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    CustomerRepo customerRepo;

    @PostMapping("/create")
    public ResponseEntity<Customer> createBooks(@RequestBody Customer customer)
    {
        try {
            Customer customer1 = customerRepo.save(customer);
            return new ResponseEntity<>(customer1, HttpStatus.CREATED);
        }
        catch(Exception e){
            return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getall")
    public ResponseEntity<List<Customer>> getCustomers(@RequestParam(required = false) String email){
        try{
            List<Customer> details=new ArrayList<>();
            if(email==null)
                customerRepo.findAll().forEach(details::add);
            else
                customerRepo.findByEmailContaining(email).forEach(details::add);
            if(details.isEmpty())
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            return new ResponseEntity<>(details,HttpStatus.OK);
        }
        catch(Exception e){
            return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
