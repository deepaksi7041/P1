package com.maveric.customerwithMongoDB.repository;



import com.maveric.customerwithMongoDB.model.Customer;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerRepo extends MongoRepository<Customer,Long> {
    @Query("{email_id :?0}")
    List<Customer> findByEmailContaining(String email);
}
