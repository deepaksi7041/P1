package com.maveric.accountwithMySQL.service;


import com.maveric.accountwithMySQL.model.Account;
import com.maveric.accountwithMySQL.repository.AccountRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class AccountService {
    @Autowired
    AccountRepo accountRepo;

    public List<Account> getAccounts(){
        return (List<Account>) accountRepo.findAll();
    }

    public Account createAccount(Account account){
        return accountRepo.save(account);
    }

}
