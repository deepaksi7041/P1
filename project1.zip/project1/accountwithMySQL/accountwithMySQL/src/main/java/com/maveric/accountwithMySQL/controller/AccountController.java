package com.maveric.accountwithMySQL.controller;


import com.maveric.accountwithMySQL.model.Account;
import com.maveric.accountwithMySQL.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/account")
public class AccountController {
    @Autowired
    AccountService accountService;

    @GetMapping("/getAccount")
    public List<Account> getAccounts(){
        return accountService.getAccounts();
    }

    @PostMapping("/createAccount")
    public String createAccount(@RequestBody Account account)
    {
        if(accountService.createAccount(account)!=null)
            return "Success";
        return "Failure";
    }
}
